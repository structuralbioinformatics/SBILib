from connect import Connect
from uniprot import Uniprot

__all__ = ["Connect", "Uniprot"]

from .DSSPExe import DSSPExe
from .DSSP    import DSSP
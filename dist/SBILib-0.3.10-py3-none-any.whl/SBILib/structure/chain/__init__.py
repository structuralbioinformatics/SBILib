from .Chain             import Chain
from .ChainOfProtein    import ChainOfProtein
from .ChainOfNucleotide import ChainOfNucleotide